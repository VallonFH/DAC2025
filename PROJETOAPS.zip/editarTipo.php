<?php
header('Content-Type: application/json');
require 'conexao.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? 0;
$nome = $input['nome'] ?? '';

if (!$id || empty($nome)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Dados inválidos!']);
    exit;
}

$stmt = $pdo->prepare("UPDATE tbPessoaTipo SET nome = :nome WHERE id = :id");
$stmt->execute(['nome' => $nome, 'id' => $id]);
echo json_encode(['sucesso' => true]);
?>