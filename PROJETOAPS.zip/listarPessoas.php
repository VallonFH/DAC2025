<?php
header('Content-Type: application/json');
require 'conexao.php';

$stmt = $pdo->query("SELECT p.*, t.nome AS tipo_nome FROM cadastro_tbPessoas p LEFT JOIN tbPessoaTipo t ON p.tipo_id = t.id");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>