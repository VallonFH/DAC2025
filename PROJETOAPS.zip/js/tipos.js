document.addEventListener('DOMContentLoaded', () => {
    listarTipos();
});

async function salvarTipo() {
    const id = document.getElementById('tipo_id').value;
    const nome = document.getElementById('nome').value.trim();

    if (!nome) return alert('Preencha o nome!');

    const endpoint = id ? 'editarTipo.php' : 'salvarTipo.php';
    const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, nome })
    });
    const data = await res.json();
    if (data.sucesso) {
        alert('Tipo salvo com sucesso!');
        limparCampos();
        listarTipos();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

async function listarTipos() {
    const res = await fetch('listarTipos.php');
    const tipos = await res.json();
    const tbody = document.querySelector('#tabelaTipos tbody');
    tbody.innerHTML = '';
    tipos.forEach(t => {
        tbody.innerHTML += `
            <tr>
                <td>${t.id}</td>
                <td>${t.nome}</td>
                <td>
                    <button onclick="editarTipo(${t.id})">Editar</button>
                    <button onclick="excluirTipo(${t.id})">Excluir</button>
                </td>
            </tr>
        `;
    });
}

async function editarTipo(id) {
    const res = await fetch(`getTipo.php?id=${id}`);
    const data = await res.json();
    if (data.sucesso) {
        document.getElementById('tipo_id').value = data.tipo.id;
        document.getElementById('nome').value = data.tipo.nome;
    }
}

async function excluirTipo(id) {
    if (!confirm('Excluir?')) return;
    const res = await fetch('excluirTipo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.sucesso) {
        listarTipos();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

function limparCampos() {
    document.getElementById('tipo_id').value = '';
    document.getElementById('nome').value = '';
}