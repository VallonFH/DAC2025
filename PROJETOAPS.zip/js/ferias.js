document.addEventListener('DOMContentLoaded', () => {
    carregarPessoas();
    listarFerias();

    // Pré-seleciona pessoa se passado no URL
    const urlParams = new URLSearchParams(window.location.search);
    const pessoaId = urlParams.get('pessoa_id');
    if (pessoaId) document.getElementById('pessoa_id').value = pessoaId;
});

async function carregarPessoas() {
    const res = await fetch('listarPessoas.php');
    const pessoas = await res.json();
    const select = document.getElementById('pessoa_id');
    select.innerHTML = '<option value="">Selecione a Pessoa</option>';
    pessoas.forEach(p => {
        select.innerHTML += `<option value="${p.id}">${p.nome}</option>`;
    });
}

async function salvarFerias() {
    const id = document.getElementById('ferias_id').value;
    const pessoa_id = document.getElementById('pessoa_id').value;
    const data_inicio = document.getElementById('data_inicio').value;
    const data_fim = document.getElementById('data_fim').value;
    const descricao = document.getElementById('descricao').value.trim();

    if (!pessoa_id || !data_inicio || !data_fim) return alert('Preencha os campos obrigatórios!');

    const endpoint = id ? 'editarFerias.php' : 'salvarFerias.php';
    const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, pessoa_id, data_inicio, data_fim, descricao })
    });
    const data = await res.json();
    if (data.sucesso) {
        alert('Férias salvas com sucesso!');
        limparCampos();
        listarFerias();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

async function listarFerias() {
    const res = await fetch('listarFerias.php');
    const ferias = await res.json();
    const tbody = document.querySelector('#tabelaFerias tbody');
    tbody.innerHTML = '';
    ferias.forEach(f => {
        tbody.innerHTML += `
            <tr>
                <td>${f.id}</td>
                <td>${f.pessoa_nome}</td>
                <td>${f.data_inicio}</td>
                <td>${f.data_fim}</td>
                <td>${f.descricao}</td>
                <td>
                    <button onclick="editarFerias(${f.id})">Editar</button>
                    <button onclick="excluirFerias(${f.id})">Excluir</button>
                </td>
            </tr>
        `;
    });
}

async function editarFerias(id) {
    const res = await fetch(`getFerias.php?id=${id}`);
    const data = await res.json();
    if (data.sucesso) {
        document.getElementById('ferias_id').value = data.ferias.id;
        document.getElementById('pessoa_id').value = data.ferias.pessoa_id;
        document.getElementById('data_inicio').value = data.ferias.data_inicio;
        document.getElementById('data_fim').value = data.ferias.data_fim;
        document.getElementById('descricao').value = data.ferias.descricao;
    }
}

async function excluirFerias(id) {
    if (!confirm('Excluir?')) return;
    const res = await fetch('excluirFerias.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.sucesso) {
        listarFerias();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

function limparCampos() {
    document.getElementById('ferias_id').value = '';
    document.getElementById('pessoa_id').value = '';
    document.getElementById('data_inicio').value = '';
    document.getElementById('data_fim').value = '';
    document.getElementById('descricao').value = '';
}