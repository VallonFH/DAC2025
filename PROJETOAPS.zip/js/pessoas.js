document.addEventListener('DOMContentLoaded', () => {
    carregarTipos();
    listarPessoas(); // Carrega lista, mas tabela inicia escondida
});

async function carregarTipos() {
    const res = await fetch('listarTipos.php');
    const tipos = await res.json();
    const select = document.getElementById('tipo');
    select.innerHTML = '<option value="">Selecione o tipo</option>';
    tipos.forEach(tipo => {
        select.innerHTML += `<option value="${tipo.id}">${tipo.nome}</option>`;
    });
}

async function salvarPessoa() {
    const id = document.getElementById('pessoa_id').value;
    const nome = document.getElementById('nome').value.trim();
    const descricao = document.getElementById('descricao').value.trim();
    const tipo_id = document.getElementById('tipo').value;

    if (!nome) return alert('Preencha o nome!');

    const endpoint = id ? 'editarPessoa.php' : 'salvarPessoa.php';
    const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, nome, descricao, tipo_id })
    });
    const data = await res.json();
    if (data.sucesso) {
        alert('Pessoa salva com sucesso!');
        limparCampos();
        listarPessoas();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

async function listarPessoas() {
    const res = await fetch('listarPessoas.php');
    const pessoas = await res.json();
    const tbody = document.querySelector('#tabelaPessoas tbody');
    tbody.innerHTML = '';
    pessoas.forEach(p => {
        tbody.innerHTML += `
            <tr>
                <td>${p.id}</td>
                <td>${p.nome}</td>
                <td>${p.descricao}</td>
                <td>${p.tipo_nome || 'N/A'}</td>
                <td>
                    <button onclick="editarPessoa(${p.id})">Editar</button>
                    <button onclick="excluirPessoa(${p.id})">Excluir</button>
                    <button onclick="window.location.href='ferias.html?pessoa_id=${p.id}'">Adicionar Férias</button>
                </td>
            </tr>
        `;
    });
}

async function editarPessoa(id) {
    const res = await fetch(`getPessoa.php?id=${id}`);
    const data = await res.json();
    if (data.sucesso) {
        document.getElementById('pessoa_id').value = data.pessoa.id;
        document.getElementById('nome').value = data.pessoa.nome;
        document.getElementById('descricao').value = data.pessoa.descricao;
        document.getElementById('tipo').value = data.pessoa.tipo_id;
    }
}

async function excluirPessoa(id) {
    if (!confirm('Excluir?')) return;
    const res = await fetch('excluirPessoa.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.sucesso) {
        listarPessoas();
    } else {
        alert('Erro: ' + data.mensagem);
    }
}

function limparCampos() {
    document.getElementById('pessoa_id').value = '';
    document.getElementById('nome').value = '';
    document.getElementById('descricao').value = '';
    document.getElementById('tipo').value = '';
}

function toggleLista() {
    const tabela = document.getElementById('tabelaPessoas');
    tabela.style.display = tabela.style.display === 'none' ? 'table' : 'none';
}

function adicionarFerias() {
    window.location.href = 'ferias.html';
}