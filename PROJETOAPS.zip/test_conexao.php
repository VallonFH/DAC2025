<?php
require 'conexao.php';
echo 'Conectado com sucesso ao banco ' . $dbname . '!';
?>