<?php
header('Content-Type: application/json');
require 'conexao.php';

$input = json_decode(file_get_contents('php://input'), true);
$nome = $input['nome'] ?? '';

if (empty($nome)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Nome obrigatório!']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO tbPessoaTipo (nome) VALUES (:nome)");
$stmt->execute(['nome' => $nome]);
echo json_encode(['sucesso' => true]);
?>