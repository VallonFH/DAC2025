<?php
header('Content-Type: application/json');
require 'conexao.php';

$stmt = $pdo->query("SELECT f.*, p.nome AS pessoa_nome FROM tbFerias f JOIN cadastro_tbPessoas p ON f.pessoa_id = p.id");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>