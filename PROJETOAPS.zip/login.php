<?php
// login.php
include 'conexao.php';

// Recebe os dados enviados pelo fetch
$data = json_decode(file_get_contents("php://input"), true);

$login = $conn->real_escape_string($data['login']);
$senha = $conn->real_escape_string($data['senha']);

// Consulta para validar usuário
$sql = "SELECT * FROM seguranca_tbUsuarios WHERE login='$login' AND senha='$senha'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo json_encode(["sucesso" => true]);
} else {
    echo json_encode(["sucesso" => false]);
}
?>
