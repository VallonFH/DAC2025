<?php
header('Content-Type: application/json');
require 'conexao.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? 0;

if (!$id) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'ID inválido!']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM tbPessoaTipo WHERE id = :id");
$stmt->execute(['id' => $id]);
echo json_encode(['sucesso' => true]);
?>