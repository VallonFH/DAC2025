<?php
header('Content-Type: application/json');
require 'conexao.php';

$stmt = $pdo->query("SELECT * FROM tbPessoaTipo");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>