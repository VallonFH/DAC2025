<?php
header('Content-Type: application/json');
require 'conexao.php'; // Veja abaixo

$input = json_decode(file_get_contents('php://input'), true);
$nome = $input['nome'] ?? '';
$descricao = $input['descricao'] ?? '';
$tipo_id = $input['tipo_id'] ?? null;

if (empty($nome)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Nome obrigatório!']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO cadastro_tbPessoas (nome, descricao, tipo_id) VALUES (:nome, :descricao, :tipo_id)");
$stmt->execute(['nome' => $nome, 'descricao' => $descricao, 'tipo_id' => $tipo_id]);
echo json_encode(['sucesso' => true]);
?>