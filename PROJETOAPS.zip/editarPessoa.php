<?php
header('Content-Type: application/json');
require 'conexao.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? 0;
$nome = $input['nome'] ?? '';
$descricao = $input['descricao'] ?? '';
$tipo_id = $input['tipo_id'] ?? null;

if (!$id || empty($nome)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Dados inválidos!']);
    exit;
}

$stmt = $pdo->prepare("UPDATE cadastro_tbPessoas SET nome = :nome, descricao = :descricao, tipo_id = :tipo_id WHERE id = :id");
$stmt->execute(['nome' => $nome, 'descricao' => $descricao, 'tipo_id' => $tipo_id, 'id' => $id]);
echo json_encode(['sucesso' => true]);
?>