<?php
header('Content-Type: application/json');
require 'conexao.php';

$input = json_decode(file_get_contents('php://input'), true);
$pessoa_id = $input['pessoa_id'] ?? 0;
$data_inicio = $input['data_inicio'] ?? '';
$data_fim = $input['data_fim'] ?? '';
$descricao = $input['descricao'] ?? '';

if (!$pessoa_id || empty($data_inicio) || empty($data_fim)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Campos obrigatórios!']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO tbFerias (pessoa_id, data_inicio, data_fim, descricao) VALUES (:pessoa_id, :data_inicio, :data_fim, :descricao)");
$stmt->execute(['pessoa_id' => $pessoa_id, 'data_inicio' => $data_inicio, 'data_fim' => $data_fim, 'descricao' => $descricao]);
echo json_encode(['sucesso' => true]);
?>