<?php
header('Content-Type: application/json');
require 'conexao.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM tbPessoaTipo WHERE id = :id");
$stmt->execute(['id' => $id]);
$tipo = $stmt->fetch(PDO::FETCH_ASSOC);
echo json_encode(['sucesso' => true, 'tipo' => $tipo]);
?>