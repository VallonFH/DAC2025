<?php
header('Content-Type: application/json');

// Credenciais do banco (substitua se necessário)
$host = 'euqueroferias.mysql.dbaas.com.br';
$dbname = 'euqueroferias';
$username = 'euqueroferias';
$password = 'Vacation12345@';

try {
    // Conexão com PDO (mais seguro que mysql_)
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recebe dados do POST
    $input = json_decode(file_get_contents('php://input'), true);
    $login = $input['login'] ?? '';
    $senha = $input['senha'] ?? ''; // Aviso: Em produção, use password_hash($senha, PASSWORD_DEFAULT)

    if (empty($login) || empty($senha)) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Preencha login e senha!']);
        exit;
    }

    // Verifica se login já existe (para evitar duplicatas)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM seguranca_tbUsuarios WHERE login = :login");
    $stmt->execute(['login' => $login]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Login já existe!']);
        exit;
    }

    // Insere no banco
    $stmt = $pdo->prepare("INSERT INTO seguranca_tbUsuarios (login, senha) VALUES (:login, :senha)");
    $stmt->execute(['login' => $login, 'senha' => $senha]);

    echo json_encode(['sucesso' => true]);
} catch (PDOException $e) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Erro: ' . $e->getMessage()]);
}
?>